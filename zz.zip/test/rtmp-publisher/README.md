# RTMP Publisher

Simple RTMP publisher.

Edit the following flashvars in publisher.html & player.html to suite your needs.

streamer: RTMP endpoint
file: live stream name

## Compile

Install flex sdk http://www.adobe.com/devnet/flex/flex-sdk-download.html

    mxmlc RtmpPublisher.mxml
    mxmlc RtmpPlayer.mxml
